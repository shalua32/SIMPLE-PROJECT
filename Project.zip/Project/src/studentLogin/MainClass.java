package studentLogin;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class MainClass extends RegForm{

	
	
	
	
	
	
	
	
	
	

}
